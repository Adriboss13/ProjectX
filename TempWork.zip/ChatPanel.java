import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ChatPanel extends JPanel {
    private final JTextArea chatArea;
    private final JTextField inputField;
    private final Client client;
    private boolean isDrawer = false;
    private JPanel wordChoicePanel; // Panel pour le choix des mots

    public ChatPanel(Client client) {
        this.client = client;
        setPreferredSize(new Dimension(250, 0));
        setLayout(new BorderLayout());

        // Zone de chat
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        add(scrollPane, BorderLayout.CENTER);

        // Panel pour le choix des mots (initialement invisible)
        wordChoicePanel = new JPanel();
        wordChoicePanel.setLayout(new BoxLayout(wordChoicePanel, BoxLayout.Y_AXIS));
        wordChoicePanel.setVisible(false);
        add(wordChoicePanel, BorderLayout.NORTH);

        // Zone de saisie
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        JButton sendButton = new JButton("Envoyer");
        
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        ActionListener sendAction = e -> envoyerMessage();
        sendButton.addActionListener(sendAction);
        inputField.addActionListener(sendAction);
    }

    private void envoyerMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            if (isDrawer) {
                // Si c'est le dessinateur, il ne peut pas proposer de mot
                ajouterMessage("Vous êtes le dessinateur, vous ne pouvez pas proposer de mot");
            } else {
                // Envoyer la proposition au serveur
                client.envoyerMessageAuServeur("GUESS:" + message);
            }
            inputField.setText("");
        }
    }

    public void ajouterMessage(String message) {
        if (message.startsWith("MOTS_PROPOSITION:")) {
            // Afficher les choix de mots pour le dessinateur
            afficherChoixMots(message.substring(16).split(","));
        } else if (message.startsWith("GUESS:")) {
            // Afficher les propositions des autres joueurs
            chatArea.append(message.substring(6) + "\n");
        } else {
            chatArea.append(message + "\n");
        }
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private void afficherChoixMots(String[] mots) {
        wordChoicePanel.removeAll();
        wordChoicePanel.setVisible(true);
        
        JLabel label = new JLabel("Choisissez un mot à dessiner:");
        wordChoicePanel.add(label);

        for (int i = 0; i < mots.length; i++) {
            final int index = i;
            JButton wordButton = new JButton(mots[i]);
            wordButton.addActionListener(e -> {
                client.envoyerMessageAuServeur("CHOSEN_WORD:" + index);
                wordChoicePanel.setVisible(false);
            });
            wordChoicePanel.add(wordButton);
        }
        
        wordChoicePanel.revalidate();
        wordChoicePanel.repaint();
    }

    public void setDrawer(boolean isDrawer) {
        this.isDrawer = isDrawer;
        inputField.setEnabled(!isDrawer);
        inputField.setToolTipText(isDrawer ? "Vous êtes le dessinateur" : "Proposez un mot...");
    }
}