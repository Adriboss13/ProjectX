import java.util.ArrayList;
import java.util.List;

class Partie {
    private List<Joueur> joueurs = new ArrayList<>();
    private GestionnaireDeMot gestionnaireDeMot;
    private int tourActuel = 0;
    private Joueur dessinateur;
    private Mots motCourant;
    private Serveur serveur;  // Ajoutez une référence au serveur

    // Modifier le constructeur pour accepter un serveur en plus du chemin de fichier
    public Partie(Serveur serveur, String cheminFichier) {
        this.serveur = serveur;  // Initialisation du serveur
        gestionnaireDeMot = new GestionnaireDeMot(cheminFichier);
    }

    public void demarrerPartie(List<Serveur.ClientHandler> clients) {
        System.out.println("La partie commence !");
        for (Serveur.ClientHandler client : clients) {
            joueurs.add(client.getJoueur()); // Appel valide à getJoueur()
        }

        while (tourActuel < joueurs.size() * 3) { // 3 tours par joueur
            lancerTour(clients);
            tourActuel++;
        }
        afficherPodium();
    }

    private void lancerTour(List<Serveur.ClientHandler> clients) {
        dessinateur = joueurs.get(tourActuel % joueurs.size());
        motCourant = gestionnaireDeMot.choisirMotAleatoire();

        for (Serveur.ClientHandler client : clients) {
            if (client.getJoueur().equals(dessinateur)) {
                client.envoyerMessage("Vous êtes le dessinateur. Mot : " + motCourant.getMot());
            } else {
                client.envoyerMessage("Vous êtes un devineur. Observez et devinez le dessin !");
            }
        }
    }


    public void ajouterJoueur(Joueur joueur) {
        joueurs.add(joueur);
    }

    // private void lancerTour(List<Serveur.ClientHandler> clients) {
    //     dessinateur = joueurs.get(tourActuel % joueurs.size());
    //     motCourant = gestionnaireDeMot.choisirMotAleatoire();

    //     for (Serveur.ClientHandler client : clients) {
    //         if (client.getJoueur().equals(dessinateur)) {
    //             client.envoyerMessage("Vous êtes le dessinateur. Mot : " + motCourant.getMot());
    //         } else {
    //             client.envoyerMessage("Vous êtes un devineur. Observez et devinez le dessin !");
    //         }
    //     }
    //     // Envoi du mot au chat pour tous les joueurs
    //     serveur.broadcast("Le mot à deviner est : " + motCourant.getMot(), null);
    // }

    public boolean verifierMot(Joueur joueur, String proposition) {
        if (motCourant.getMot().equalsIgnoreCase(proposition)) {
            joueur.ajouterPoints(motCourant.getDifficulte().equals("Facile") ? 10 : 20);
            dessinateur.ajouterPoints(motCourant.getDifficulte().equals("Facile") ? 3 : 7);
            serveur.broadcast(joueur.getNom() + " a trouvé le mot : " + motCourant.getMot(), null);
            return true;
        }
        return false;
    }

    private void afficherPodium() {
        joueurs.sort((j1, j2) -> j2.getPoints() - j1.getPoints());
        System.out.println("Podium final :");
        for (int i = 0; i < joueurs.size(); i++) {
            System.out.println((i + 1) + ". " + joueurs.get(i).getNom() + " - " + joueurs.get(i).getPoints() + " points");
        }
    }
}
