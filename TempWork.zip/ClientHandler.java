import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread {
    private final Socket socket;
    private final PrintWriter out;
    private BufferedReader in;
    private boolean isRunning = true;
    private Joueur joueur;  // Ajout de l'attribut joueur
    private Server server; // Ajout d'une référence au serveur
    private Partie partie; // Ajout d'une référence à la partie

    // Modifier le constructeur pour inclure le serveur
    public ClientHandler(Socket socket, PrintWriter out, Server server) {
        this.socket = socket;
        this.out = out;
        this.server = server;
        this.joueur = new Joueur("Joueur-" + socket.getPort());
    }

    // Ajouter un setter pour la partie
    public void setPartie(Partie partie) {
        this.partie = partie;
    }

    @Override
    public void run() {
        try {
            String message;
            while (isRunning && (message = in.readLine()) != null) {
                if (message.startsWith("DRAW:")) {
                    // Diffuser les données de dessin à tous les autres clients
                    server.broadcastDrawing(message.substring(5), this);
                }
                // ... reste du code de gestion des messages ...
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void envoyerMessage(String message) {
        if (out != null) {
            out.println(message);
            out.flush();
        }
    }

    public void closeConnection() {
        try {
            isRunning = false;
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
            Server.retirerClient(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Joueur getJoueur() {
        return joueur;
    }

    public void setJoueur(Joueur joueur) {
        this.joueur = joueur;
    }
}