import java.io.*;
import java.net.*;
  
public class GameServer {
    public static void main(String[] args) {
        try {
            // 1. Crée un serveur qui écoute sur le port 12345
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Serveur démarré, en attente de connexions...");

            // 2. Accepte une connexion d’un client
            Socket clientSocket = serverSocket.accept();
            System.out.println("Un joueur s’est connecté !");

            // 3. Communication avec le client
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            // Envoie un message au client
            out.println("Bienvenue sur le serveur de dessin !");

            // Lit un message du client
            String message = in.readLine();
            System.out.println("Le client a dit : " + message);

            // Ferme la connexion
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
