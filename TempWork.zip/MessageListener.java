// La classe MessageListener hérite de Thread et écoute les messages reçus depuis le serveur pour les traiter.

import java.io.*;
import java.util.Base64;
import javax.swing.SwingUtilities;

public class MessageListener extends Thread {
    private final Client client; // Instance de la classe Client, utilisée pour communiquer avec l'interface graphique.

    // Constructeur qui prend en paramètre une instance de Client, permettant à MessageListener d'interagir avec l'interface graphique.
    public MessageListener(Client client) {
        this.client = client; // Assigne l'instance de Client à la variable membre
    }

    // La méthode run() est exécutée lors du démarrage du thread, elle écoute les messages du serveur.
    @Override
    public void run() {
        try {
            String message;
            while ((message = Client.getIn().readLine()) != null) {
                if (message.startsWith("DRAW:")) {
                    // Décodage et traitement des données de dessin
                    try {
                        byte[] data = Base64.getDecoder().decode(message.substring(5));
                        ByteArrayInputStream bais = new ByteArrayInputStream(data);
                        ObjectInputStream ois = new ObjectInputStream(bais);
                        LineData receivedLineData = (LineData) ois.readObject();
                        
                        // Important: On ajoute la ligne reçue à la liste des lignes
                        synchronized (Client.getLines()) {
                            Client.getLines().add(receivedLineData);
                        }
                        
                        // Force le rafraîchissement immédiat du panneau de dessin
                        SwingUtilities.invokeLater(() -> client.repaint());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // ... reste du code de gestion des messages ...
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleGameMessage(String message) {
        if (message.startsWith("TIME:")) {
            // Mettre à jour le chronomètre dans l'interface
            int time = Integer.parseInt(message.substring(5));
            SwingUtilities.invokeLater(() -> {
                // TODO: Mettre à jour l'affichage du temps
            });
        } else if (message.startsWith("WRONG:")) {
            // Afficher le message d'erreur dans le chat
            String errorMessage = message.substring(6);
            SwingUtilities.invokeLater(() -> {
                if (client.getChatPanel() != null) {
                    client.getChatPanel().ajouterMessage("Incorrect: " + errorMessage);
                }
            });
        }
        // Ajouter d'autres cas selon les besoins
    }

    private void handleDrawingData(String message) throws IOException, ClassNotFoundException {
        byte[] data = Base64.getDecoder().decode(message);
        ByteArrayInputStream bais = new ByteArrayInputStream(data);
        ObjectInputStream ois = new ObjectInputStream(bais);
        LineData receivedLineData = (LineData) ois.readObject();
        synchronized (Client.getLines()) {
            Client.getLines().add(receivedLineData);
        }
        SwingUtilities.invokeLater(() -> client.repaint());
    }

    private void handleChatMessage(String message) {
        SwingUtilities.invokeLater(() -> {
            ChatPanel panel = client.getChatPanel();
            if (panel != null) {
                panel.ajouterMessage(message);
            }
        });
    }

    private boolean isBase64(String str) {
        if (str == null || str.isEmpty() || str.length() % 4 != 0) {
            return false;
        }
        try {
            Base64.getDecoder().decode(str);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private void handleTimeMessage(String message) {
        int time = Integer.parseInt(message.substring(5));
        SwingUtilities.invokeLater(() -> {
            // Mise à jour du temps si nécessaire
        });
    }

    private void handleWrongMessage(String message) {
        String errorMessage = message.substring(6);
        SwingUtilities.invokeLater(() -> {
            ChatPanel panel = client.getChatPanel();
            if (panel != null) {
                panel.ajouterMessage("Incorrect: " + errorMessage);
            }
        });
    }
}