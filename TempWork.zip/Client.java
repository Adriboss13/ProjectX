// Cette classe représente un client pour une application de dessin collaboratif en réseau.
// Elle permet à plusieurs utilisateurs de dessiner ensemble en temps réel, chaque action de dessin étant synchronisée via un serveur central.

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import javax.swing.*;

public class Client extends JFrame {
    // Configuration réseau
    private static final int PORT = 12345; // Port utilisé pour se connecter au serveur
    private static final String SERVER = "127.0.0.1"; // Adresse du serveur (localhost dans ce cas)

    // Gestion de la connexion et des messages
    private static Socket socket; // Socket pour la connexion au serveur
    private static PrintWriter out; // Flux pour envoyer des données au serveur
    public static BufferedReader in; // Flux pour recevoir des données du serveur

    // Données de dessin
    public static List<LineData> lines = Collections.synchronizedList(new ArrayList<>()); // Liste des lignes dessinées (partagée entre threads)
    public static Color currentColor = Color.BLACK; // Couleur actuellement sélectionnée pour dessiner
    public static ArrayList<Point> currentLine = new ArrayList<>(); // Points de la ligne en cours de dessin

    // Interface graphique
    private JButton selectedColorButton = null; // Bouton correspondant à la couleur sélectionnée

    private ChatPanel chatPanel; // Ajout de la référence au ChatPanel

    public Client() {
        // Configuration de la fenêtre principale
        setTitle("Collaborative Drawing");
        setSize(1000, 600); // Augmenter la largeur pour accommoder le chat
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Créer un panneau principal avec BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Panneau de dessin à gauche
        DrawingPanel drawingPanel = new DrawingPanel();
        mainPanel.add(drawingPanel, BorderLayout.CENTER);

        // Panneau de chat à droite
        chatPanel = new ChatPanel(this); // Initialisation du ChatPanel
        mainPanel.add(chatPanel, BorderLayout.EAST);

        add(mainPanel);

        // Création de la palette de couleurs
        JPanel colorPanel = new JPanel();
        Color[] colors = {
            Color.RED, Color.ORANGE, Color.YELLOW,
            new Color(0, 100, 0), // Vert foncé
            new Color(144, 238, 144), // Vert clair
            Color.CYAN, Color.BLUE,
            new Color(128, 0, 128), // Violet
            Color.PINK, new Color(139, 69, 19), // Marron
            Color.GRAY, Color.BLACK, Color.WHITE // Ajout de la gomme
        };

        // Ajouter un bouton pour chaque couleur dans la palette
        for (Color color : colors) {
            JButton colorButton = new JButton();
            colorButton.setPreferredSize(new Dimension(30, 30));
            colorButton.setBackground(color);
            colorButton.setOpaque(true);
            colorButton.setBorderPainted(false);

            // Listener pour changer la couleur actuelle
            colorButton.addActionListener(e -> {
                if (selectedColorButton != null) {
                    selectedColorButton.setPreferredSize(new Dimension(30, 30)); // Réduire la taille du bouton précédent
                }
                selectedColorButton = colorButton; // Mettre à jour le bouton sélectionné
                colorButton.setPreferredSize(new Dimension(40, 40)); // Agrandir le bouton sélectionné
                currentColor = color; // Mettre à jour la couleur actuelle
                colorPanel.revalidate(); // Rafraîchir l'affichage
            });

            // Si la couleur est noire, la sélectionner par défaut
            if (color == Color.BLACK) {
                colorButton.setPreferredSize(new Dimension(40, 40));
                selectedColorButton = colorButton;
            }

            colorPanel.add(colorButton); // Ajouter le bouton à la palette
        }
        add(colorPanel, BorderLayout.NORTH);

        // Initialisation de la connexion au serveur
        try {
            socket = new Socket(SERVER, PORT); // Connexion au serveur
            out = new PrintWriter(socket.getOutputStream(), true); // Flux pour envoyer des messages
            in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // Flux pour recevoir des messages

            // Lancer un thread pour écouter les messages du serveur
            MessageListener messageListener = new MessageListener(this);
            messageListener.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Gestion des événements de la souris sur le panneau de dessin
        drawingPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                currentLine = new ArrayList<>();
                currentLine.add(e.getPoint());
                sendDrawingData();
                drawingPanel.repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                sendDrawingData();
                currentLine = new ArrayList<>();
                drawingPanel.repaint();
            }
        });

        drawingPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                currentLine.add(e.getPoint());
                sendDrawingData();
                drawingPanel.repaint();
            }
        });
    }

    // Méthode pour envoyer les données de dessin au serveur
    private void sendDrawingData() {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            
            // Créer une nouvelle LineData avec la ligne courante
            LineData lineData = new LineData(new ArrayList<>(currentLine), currentColor);
            oos.writeObject(lineData);
            
            // Envoyer au serveur avec le préfixe DRAW:
            String encodedData = Base64.getEncoder().encodeToString(baos.toByteArray());
            out.println("DRAW:" + encodedData);
            out.flush(); // Important: forcer l'envoi immédiat
            
            // Ajouter localement la ligne
            synchronized (lines) {
                lines.add(lineData);
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthodes utilitaires pour accéder aux données depuis d'autres classes
    public static List<LineData> getLines() {
        return lines;
    }

    public static Color getCurrentColor() {
        return currentColor;
    }

    public static ArrayList<Point> getCurrentLine() {
        return currentLine;
    }

    public static BufferedReader getIn() {
        return in;
    }

    public void envoyerMessageAuServeur(String message) {
        if (out != null) {
            out.println(message);
            out.flush();
        }
    }

    // Ajout de l'accesseur pour le ChatPanel
    public ChatPanel getChatPanel() {
        return chatPanel;
    }

    // Mise à jour des événements souris pour une meilleure réactivité
    private void setupMouseListeners() {
        DrawingPanel drawingPanel = new DrawingPanel();
        drawingPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                currentLine = new ArrayList<>();
                currentLine.add(e.getPoint());
                sendDrawingData();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (!currentLine.isEmpty()) {
                    currentLine.add(e.getPoint());
                    sendDrawingData();
                    currentLine = new ArrayList<>();
                }
            }
        });

        drawingPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (currentLine != null) {
                    currentLine.add(e.getPoint());
                    sendDrawingData();
                }
            }
        });
    }



    // Point d'entrée du programme
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java Client <IP> <PORT>");
            System.exit(1);
        }
    
        String serverAddress = args[0];
        int port;
        try {
            port = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.err.println("Le port doit être un nombre entier.");
            System.exit(1);
            return; // Ajouté pour satisfaire le compilateur
        }
    
        // Configurer l'adresse et le port à partir des arguments
        try {
            socket = new Socket(serverAddress, port); // Connexion au serveur
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    
            SwingUtilities.invokeLater(() -> {
                Client client = new Client(); // Créer une nouvelle instance du client
                client.setVisible(true); // Afficher l'interface graphique
            });
        } catch (IOException e) {
            System.err.println("Impossible de se connecter au serveur: " + e.getMessage());
            System.exit(1);
        }
    }
}