import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class Client {
    private static final String HOST = "localhost";
    private static final int PORT = 12345;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private Point dernierPoint = null; // Pour garder une trace du dernier point dessiné

    public static void main(String[] args) {
        new Client().lancerInterface();
    }

    public void lancerInterface() {
        JFrame frame = new JFrame("Dessiner c'est Gagné - Client");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Zone de dessin
        JPanel panneauDessin = new JPanel() {
            {
                addMouseMotionListener(new MouseMotionAdapter() {
                    public void mouseDragged(MouseEvent e) {
                        Graphics g = getGraphics();
                        if (dernierPoint != null) {
                            g.drawLine(dernierPoint.x, dernierPoint.y, e.getX(), e.getY());
                            // Envoyer les coordonnées de la ligne entre dernierPoint et le nouveau point
                            out.println("DRAW:" + dernierPoint.x + "," + dernierPoint.y + "," + e.getX() + "," + e.getY());
                        }
                        dernierPoint = e.getPoint(); // Mettre à jour le dernier point
                    }
                });

                addMouseListener(new MouseAdapter() {
                    public void mouseReleased(MouseEvent e) {
                        dernierPoint = null; // Réinitialiser dernierPoint quand l'utilisateur relâche la souris
                    }
                });
            }

            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                setBackground(Color.WHITE);
            }
        };
        panneauDessin.setPreferredSize(new Dimension(600, 400));

        // Zone de chat
        JTextArea chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane chatScrollPane = new JScrollPane(chatArea);
        chatScrollPane.setPreferredSize(new Dimension(600, 150));

        JTextField chatInput = new JTextField();
        chatInput.addActionListener(e -> {
            String message = chatInput.getText();
            out.println(message);
            chatInput.setText("");
        });

        frame.add(panneauDessin, BorderLayout.CENTER);
        frame.add(chatScrollPane, BorderLayout.SOUTH);
        frame.add(chatInput, BorderLayout.NORTH);

        frame.setVisible(true);

        // Connexion au serveur
        try {
            socket = new Socket(HOST, PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Thread pour recevoir les messages du serveur
            Thread receptionMessages = new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        if (message.startsWith("Le mot à deviner est :")) {
                            chatArea.append("Le mot à deviner est : " + message.substring(22) + "\n");
                        } else if (message.startsWith("DRAW:")) {
                            // Dessiner la ligne envoyée par l'autre client
                            String[] coords = message.substring(5).split(",");
                            int x1 = Integer.parseInt(coords[0]);
                            int y1 = Integer.parseInt(coords[1]);
                            int x2 = Integer.parseInt(coords[2]);
                            int y2 = Integer.parseInt(coords[3]);

                            // Relier les points successifs pour former une ligne continue
                            Graphics g = panneauDessin.getGraphics();
                            g.drawLine(x1, y1, x2, y2);
                            
                        } else {
                            chatArea.append(message + "\n");
                        }
                    }
                } catch (IOException e) {
                    chatArea.append("Connexion perdue avec le serveur.\n");
                }
            });
            receptionMessages.start();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Impossible de se connecter au serveur.");
            System.exit(1);
        }
    }
}


