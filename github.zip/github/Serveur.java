import java.io.*;
import java.net.*;
import java.util.*;

public class Serveur {
    private static final int PORT = 12345;
    private List<ClientHandler> clients = new ArrayList<>();
    private Partie partie;

    public static void main(String[] args) {
        new Serveur().demarrer();
    }

    public void demarrer() {
        System.out.println("Serveur en cours de démarrage...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur démarré sur le port " + PORT);

            // Création de la partie avec le serveur et le chemin du fichier Mots.txt
            partie = new Partie(this, "Mots.txt");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Nouveau joueur connecté.");
                ClientHandler clientHandler = new ClientHandler(socket, this);
                clients.add(clientHandler);
                new Thread(clientHandler).start();

                if (clients.size() == 3) { // Vérifiez si tous les joueurs sont connectés
                    // Attendre que tous les joueurs saisissent leur nom
                    synchronized (this) {
                        // Diffuser le message de départ à tous les joueurs
                        broadcast("Tous les joueurs sont prêts. La partie commence !", null);
                        partie.demarrerPartie(clients);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void broadcast(String message, ClientHandler excludeClient) {
        for (ClientHandler client : clients) {
            if (client != excludeClient) {
                client.envoyerMessage(message);
            }
        }
    }

    public void broadcastDrawing(String drawingData, ClientHandler excludeClient) {
        for (ClientHandler client : clients) {
            // Diffuse le dessin à tous les clients sauf à celui qui l'a envoyé
            if (client != excludeClient) {
                client.envoyerMessage("DRAW:" + drawingData);
            }
        }
    }


    public Partie getPartie() {
        return partie;
    }

    class ClientHandler implements Runnable {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private Serveur serveur;
        private Joueur joueur;

        public ClientHandler(Socket socket, Serveur serveur) {
            this.socket = socket;
            this.serveur = serveur;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                out.println("Bienvenue ! Entrez votre nom :");
                String nom = in.readLine();
                joueur = new Joueur(nom);
                serveur.getPartie().ajouterJoueur(joueur);

                out.println("En attente des autres joueurs...");

                if (serveur.clients.size() == 3) {
                    serveur.broadcast("Tous les joueurs sont prêts. La partie commence !", null);
                    serveur.getPartie().demarrerPartie(serveur.clients);
                }

                while (true) {
                    String message = in.readLine();
                    if (message != null) {
                        if (message.startsWith("DRAW:")) {
                            // Diffuser l'instruction de dessin
                            serveur.broadcastDrawing(message.substring(5), this);
                        } else {
                            // Diffuse le message dans le chat
                            serveur.broadcast(joueur.getNom() + ": " + message, this);
                            // Vérifie si quelqu'un a trouvé le mot
                            if (serveur.getPartie().verifierMot(joueur, message)) {
                                out.println("Bravo, vous avez trouvé le mot !");
                                serveur.broadcast(joueur.getNom() + " a trouvé le mot : " + message, this);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                serveur.clients.remove(this);
            }
        }

        public void envoyerMessage(String message) {
            out.println(message);
        }

        public Joueur getJoueur() {
            return joueur;
        }
    }
}

//bien