import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

class Partie {
    private List<Joueur> joueurs = new ArrayList<>();
    private Mots motCourant;
    private Joueur dessinateur;
    private int chrono = 60;
    private int tours;
    private int toursRestants = 9;
    private GestionnaireMots gestionnaireDeMot;
    private Map<Joueur, Integer> toursJoues = new HashMap<>();
    private List<Mots> propositionsMots = new ArrayList<>();
    private Set<Joueur> joueursAyantDevine = new HashSet<>();
    private long debutTour;
    private boolean motChoisi = false; // Nouveau flag pour suivre si un mot a été choisi

    // Crée une nouvelle partie avec des joueurs fictifs
    public void creerPartie() throws IOException {
        if (joueurs.isEmpty()) {
            throw new IllegalStateException("Impossible de créer une partie sans joueurs");
        }

        gestionnaireDeMot = new GestionnaireMots();
        gestionnaireDeMot.chargerMotsDepuisFichier("mots.txt");

        toursRestants = joueurs.size() * 3;
        
        // Initialiser toursJoues pour chaque joueur
        for (Joueur joueur : joueurs) {
            toursJoues.put(joueur, 0);
        }

        attribuerRoles();
        proposerMotsAuDessinateur();
    }

    // Attribue les rôles (dessinateur et devineurs)
    public void attribuerRoles() {
        if (joueurs.isEmpty()) {
            throw new IllegalStateException("Impossible d'attribuer les rôles sans joueurs");
        }
        // Choisir un dessinateur aléatoire pour commencer
        int indexDessinateur = new Random().nextInt(joueurs.size());
        dessinateur = joueurs.get(indexDessinateur);
        System.out.println(dessinateur.getNom() + " est le dessinateur.");
    }

    // Propose un mot au dessinateur
    public void proposerMotAuDessinateur() {
        motCourant = gestionnaireDeMot.obtenirMotAleatoire();
        System.out.println("Mot choisi pour le dessinateur : " + motCourant.getMot());
    }

    private void proposerMotsAuDessinateur() {
        propositionsMots.clear();
        // Proposer deux mots aléatoires
        propositionsMots.add(gestionnaireDeMot.obtenirMotAleatoire());
        propositionsMots.add(gestionnaireDeMot.obtenirMotAleatoire());
    }

    public void choisirMot(int indexMot) {
        if (indexMot >= 0 && indexMot < propositionsMots.size()) {
            motCourant = propositionsMots.get(indexMot);
            debutTour = System.currentTimeMillis();
            motChoisi = true; // Marquer qu'un mot a été choisi
        }
    }

    public boolean verifierProposition(Joueur joueur, String proposition) {
        if (!motChoisi) {
            return false; // Pas de vérification si aucun mot n'est choisi
        }
        
        if (dessinateur.equals(joueur)) {
            return false; // Le dessinateur ne peut pas deviner
        }
        
        if (joueursAyantDevine.contains(joueur)) {
            return false; // Le joueur a déjà deviné
        }

        if (verifierMot(proposition)) {
            int points = calculerPoints(joueur);
            joueur.ajouterPoints(points);
            joueursAyantDevine.add(joueur);

            if (joueursAyantDevine.size() == 1) {
                dessinateur.ajouterPoints(5); // Points pour le dessinateur
            }

            if (joueursAyantDevine.size() == joueurs.size() - 1) {
                finirTour();
            }

            return true;
        }
        return false;
    }

    private int calculerPoints(Joueur joueur) {
        int points = 10; // Points de base

        // Bonus de rapidité
        long tempsEcoule = (System.currentTimeMillis() - debutTour) / 1000;
        if (tempsEcoule <= 30) {
            points += 5;
        }

        // Bonus de difficulté
        if (motCourant.getDifficulte() > 1) {
            points = 20;
        }

        return points;
    }

    // Modifié pour gérer le cas où aucun mot n'est choisi
    public boolean verifierMot(String proposition) {
        if (!motChoisi || motCourant == null) {
            return false; // Retourner false si aucun mot n'a été choisi
        }
        return motCourant.getMot().equalsIgnoreCase(proposition);
    }

    // Attribue des points à un joueur
    public void attribuerPoints(Joueur joueur) {
        joueur.ajouterPoints(10);
        System.out.println("10 points attribués à " + joueur.getNom());
    }

    // Retourne la liste des joueurs
    public List<Joueur> getJoueurs() {
        return joueurs;
    }

    // Ajoute un joueur à la partie
    public void ajouterJoueur(Joueur joueur) {
        joueurs.add(joueur);
        System.out.println(joueur.getNom() + " a rejoint la partie.");
    }

    // Retire un joueur de la partie
    public void retirerJoueur(Joueur joueur) {
        joueurs.remove(joueur);
        System.out.println(joueur.getNom() + " a quitté la partie.");
    }

    // Obtient le dessinateur actuel
    public Joueur getDessinateur() {
        return dessinateur;
    }

    // Obtient le mot courant
    public Mots getMotCourant() {
        return motCourant;
    }

    // Définit le nombre de tours
    public void setTours(int tours) {
        this.tours = tours;
    }

    // Obtient le nombre de tours restants
    public int getTours() {
        return tours;
    }

    // Méthode pour obtenir les propositions de mots
    public List<Mots> getPropositionsMots() {
        return propositionsMots;
    }

    private void finirTour() {
        motChoisi = false; // Réinitialiser le flag
        toursJoues.put(dessinateur, toursJoues.getOrDefault(dessinateur, 0) + 1);
        toursRestants--;
        joueursAyantDevine.clear();

        if (toursRestants > 0) {
            changerDessinateur();
            proposerMotsAuDessinateur();
        } else {
            finirPartie();
        }
    }

    private void changerDessinateur() {
        int indexActuel = joueurs.indexOf(dessinateur);
        int indexSuivant = (indexActuel + 1) % joueurs.size();
        dessinateur = joueurs.get(indexSuivant);
    }

    private void finirPartie() {
        // Trier les joueurs par points
        List<Joueur> podium = new ArrayList<>(joueurs);
        Collections.sort(podium, (j1, j2) -> j2.getPoints() - j1.getPoints());

        // Afficher le podium
        new Podium().afficher(podium);
    }

    public void decrementChrono() {
        chrono--;
        if (chrono <= 0) {
            finirTour();
            chrono = 60; // Réinitialiser pour le prochain tour
        }
    }

    public boolean isMotChoisi() {
        return motChoisi;
    }
}