import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private static final int PORT = 12345;
    private static final List<ClientHandler> clients = new CopyOnWriteArrayList<>();
    private Partie partieEnCours;
    private final GestionnaireMots gestionnaireMots;
    private boolean partieCommencee = false;

    public Server() {
        this.gestionnaireMots = new GestionnaireMots();
        try {
            this.gestionnaireMots.chargerMotsDepuisFichier("mots.txt");
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement des mots: " + e.getMessage());
        }
    }

    // Dans Server.java, modifier la partie où on crée le ClientHandler
    public void demarrer() {
        System.out.println("Serveur démarré sur le port " + PORT);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nouveau client connecté: " + clientSocket.getInetAddress());

                // Création du gestionnaire de client avec référence au serveur
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                ClientHandler clientHandler = new ClientHandler(clientSocket, out, this);
                clients.add(clientHandler);
                
                // Si une partie est en cours, l'associer au client
                if (partieEnCours != null) {
                    clientHandler.setPartie(partieEnCours);
                }
                
                clientHandler.start();

                // Vérifier si on peut démarrer une partie
                verifierDemarragePartie();
            }
        } catch (IOException e) {
            System.err.println("Erreur serveur: " + e.getMessage());
        }
    }

    // Méthode statique pour accéder à la liste des clients
    public static List<ClientHandler> getClients() {
        return clients;
    }

    private synchronized void verifierDemarragePartie() {
        if (clients.size() >= 2 && !partieCommencee) {
            demarrerPartie();
        }
    }

    private void demarrerPartie() {
        partieCommencee = true;
        partieEnCours = new Partie();
        
        // Ajouter tous les joueurs à la partie
        for (ClientHandler client : clients) {
            partieEnCours.ajouterJoueur(client.getJoueur());
        }

        try {
            partieEnCours.creerPartie();
            broadcastMessage("GAME_START");

            // Envoyer les informations appropriées aux joueurs
            Joueur dessinateur = partieEnCours.getDessinateur();
            for (ClientHandler client : clients) {
                if (client.getJoueur().equals(dessinateur)) {
                    // Proposer les mots au dessinateur
                    List<Mots> propositions = partieEnCours.getPropositionsMots();
                    if (!propositions.isEmpty()) {
                        String motsProposition = propositions.get(0).getMot();
                        if (propositions.size() > 1) {
                            motsProposition += "," + propositions.get(1).getMot();
                        }
                        client.envoyerMessage("MOTS_PROPOSITION:" + motsProposition);
                    }
                } else {
                    client.envoyerMessage("YOU_ARE_GUESSER");
                }
            }

            demarrerChrono();
        } catch (IOException e) {
            System.err.println("Erreur lors du démarrage de la partie: " + e.getMessage());
        }
    }

    private void demarrerChrono() {
        Chrono chrono = new Chrono(60); // 60 secondes par tour
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            chrono.decrementer();
            broadcastMessage("TIME:" + chrono.getTempsRestant());

            if (chrono.getTempsRestant() <= 0) {
                scheduler.shutdown();
                finDeTour();
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    private void finDeTour() {
        broadcastMessage("ROUND_END");
        // Réinitialiser le dessin pour tous les clients
        broadcastMessage("CLEAR_DRAWING");

        if (partieEnCours != null) {
            // Afficher le podium actuel
            List<Joueur> joueurs = partieEnCours.getJoueurs();
            Podium podium = new Podium();
            podium.afficher(joueurs);
        }
    }

    public void broadcastMessage(String message) {
        for (ClientHandler client : clients) {
            client.envoyerMessage(message);
        }
    }

    public void broadcastDrawing(String drawingData, ClientHandler sender) {
        for (ClientHandler client : clients) {
            if (client != sender) { // Ne pas renvoyer au client qui a envoyé
                client.envoyerMessage("DRAW:" + drawingData);
            }
        }
    }

    public static void retirerClient(ClientHandler client) {
        clients.remove(client);
        System.out.println("Client déconnecté. Clients restants: " + clients.size());
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.demarrer();
    }

    private ClientHandler getClientHandlerForJoueur(Joueur joueur) {
        // Trouver le ClientHandler correspondant au joueur
        return clients.stream()
                     .filter(ch -> ch.getJoueur().equals(joueur))
                     .findFirst()
                     .orElse(null);
    }
}